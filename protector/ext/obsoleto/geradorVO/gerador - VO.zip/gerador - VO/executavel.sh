#!/bin/bash
java -jar GeradorVO.jar
